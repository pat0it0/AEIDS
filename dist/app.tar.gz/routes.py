# app/routes.py
class R:
    LOGIN = "/"
    DASH  = "/dashboard"
    CONEX = "/conexiones"
    ACERCA= "/acerca"
    ORD_NUEVA    = "/orden/nueva"
    ORD_NOTAS    = "/orden/notas"
    ORD_PARTES   = "/orden/partes"
    ORD_SERVICIOS= "/orden/servicios"
    ORD_REPORTE  = "/orden/reporte" 