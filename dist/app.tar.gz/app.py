import flet as ft
from view.simple_view import main

if __name__ == '__main__':
    ft.app(target=main)
